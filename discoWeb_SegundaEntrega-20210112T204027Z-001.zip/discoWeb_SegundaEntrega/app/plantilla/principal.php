<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>CRUD DE USUARIOS</title>
<link href="web/css/default.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="web/js/funciones.js"></script>
</head>
<body>
<div id="container">
<div id="header">
<h1>MI DISCO EN LA NUBE versión 1.0</h1>
</div>
<div id="content">
<?= $contenido ?>
</div>
</div>
</body>
</html>
